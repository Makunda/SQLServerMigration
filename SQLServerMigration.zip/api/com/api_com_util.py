import json

from api.flask_app import flask_application
from api.interfaces.api_response import ApiResponse


class ApiComUtil:
    """
    Api Communication Util
    """

