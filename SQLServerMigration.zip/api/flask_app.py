from socket import SocketIO

from flask import Flask
from flask_cors import CORS, cross_origin

# Create a new Application
from api.controllers.api_controller import api_controller

flask_application = Flask(__name__)
flask_application.debug = True

# Start the web socket server
socket_io = SocketIO(flask_application)

# Apply a non restrictive policy
cors = CORS(flask_application, resources={r"/api/*": {"origins": "*"}})

# Register the Blueprints / Controllers
flask_application.register_blueprint(api_controller)
