
class GraphEdge:
    source: int
    target: int
