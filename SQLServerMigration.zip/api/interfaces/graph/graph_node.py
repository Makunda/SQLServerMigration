class GraphNode:
    id: int
    size: int
    label: str
    color: str
