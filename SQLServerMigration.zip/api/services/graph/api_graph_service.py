
class ApiGraphService:

    def get_graph_node(self):
        pass