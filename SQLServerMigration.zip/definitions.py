import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
COMMAND_LINE_ARGS = {}

# Logging
LOG_FILE = None
ERROR_FILE = None
